<div class="flex flex-col">
    <h2 class="text-gray-800 text-3xl font-semibold mb-5"><?php echo e($translator->translate($block,'title')); ?></h2>
    <?php if(!empty($block['content'])): ?>
        <div class="text-gray-900 mb-6">
            <?php echo $translator->translate($block,'content'); ?>

        </div>
    <?php endif; ?>
    <div class="flex flex-col gap-4">
        <?php $__currentLoopData = $block['value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex gap-4 max-sm:flex-col">
            <?php if(!empty($value['icon'])): ?>
                <div>
                    <?php echo $value['icon']; ?>

                </div>
            <?php endif; ?>
            <div class="">
                <?php if(!empty($value['title'])): ?>
                    <p class="text-gray-800 text-lg mb-1 font-semibold"><?php echo e($translator->translate($value,'title')); ?></p>
                <?php endif; ?>
                <?php if(!empty($value['content'])): ?>
                <div class="text-gray-600">
                    <?php echo $translator->translate($value,'content'); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/resources/views/blocks/why_us.blade.php ENDPATH**/ ?>