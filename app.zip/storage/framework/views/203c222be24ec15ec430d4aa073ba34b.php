<p
    <?php echo e($attributes->class(['fi-ta-empty-state-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/vendor/filament/tables/src/../resources/views/components/empty-state/description.blade.php ENDPATH**/ ?>