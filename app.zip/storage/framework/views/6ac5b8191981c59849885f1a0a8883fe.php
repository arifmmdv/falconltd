<?php if(!empty($page->content)): ?>
    <?php $__currentLoopData = json_decode(json_encode($page->content)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make("blocks.$block->type", ['block' => json_decode(json_encode($block->data), true)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/resources/views/blocks/blocks.blade.php ENDPATH**/ ?>