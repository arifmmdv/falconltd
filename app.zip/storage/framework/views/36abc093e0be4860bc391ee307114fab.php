<h2 class="text-gray-800 text-3xl font-semibold mb-5"><?php echo e($translator->translate($block,'title')); ?></h2>

<div class="flex flex-col gap-6">
    <?php $__currentLoopData = $block['service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col gap-4">
            <?php if(!empty($service['title'])): ?>
                <h3 class="text-xl font-medium"><?php echo e($translator->translate($service,'title')); ?></h3>
            <?php endif; ?>
            <?php if(!empty($service['content'])): ?>
                <div class="flex flex-col gap-4 services">
                    <?php echo $translator->translate($service,'content'); ?>

                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/resources/views/blocks/services.blade.php ENDPATH**/ ?>