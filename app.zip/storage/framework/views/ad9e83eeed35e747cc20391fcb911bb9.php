<?php
    $languages = ['en','tr'];
?>
<div class="fixed w-full p-4 z-30">
    <div class="menu rounded-lg px-8 py-2">
        <div class="flex justify-between align-middle">
            <div class="logo">
                <?php echo $__env->make('.components.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <ul class="flex align-middle gap-4 max-lg:hidden">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex flex-col justify-center">
                        <a href="#<?php echo e($page->slug); ?>" class="menu-item block py-1.5 px-4 rounded transition duration-300 border border-white/70 shadow-md text-gray-800 bg-white/70 backdrop-blur-md hover:border-primary"><?php echo e($translator->translate($page,'title')); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="max-lg:hidden">
                <div class="flex gap-4 bg-white/70 py-1.5 px-4 rounded backdrop-blur-md">
                    <a href="/<?php echo e(app()->getLocale()); ?>" class="text-primary font-medium uppercase"><?php echo e(app()->getLocale()); ?></a>
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($language !== app()->getLocale()): ?>
                            <a href="/<?php echo e($language); ?>" class="text-gray-600 font-medium uppercase"><?php echo e($language); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="hidden max-lg:block">
                <button id="mobile-menu-button" class="p-2 text-primary bg-white/70 backdrop-blur-md rounded">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-menu-2" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M4 6l16 0" />
                        <path d="M4 12l16 0" />
                        <path d="M4 18l16 0" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="mobile-menu fixed bg-white/80 backdrop-blur-md z-50 py-8 px-4 flex flex-col justify-end gap-8" id="mobile-menu">
    <button class="absolute mobile-menu-close">
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-x" width="24" height="24" viewBox="0 0 24 24" stroke-width="1.5" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <path d="M18 6l-12 12" />
            <path d="M6 6l12 12" />
        </svg>
    </button>
    <ul class="flex flex-col gap-4">
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex flex-col justify-center items-end">
                <a href="#<?php echo e($page->slug); ?>" class="menu-item block py-1.5 px-4 transition duration-300 text-gray-800 hover:border-primary"><?php echo e($translator->translate($page,'title')); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <ul class="flex justify-end gap-4 pr-4">
        <a href="/<?php echo e(app()->getLocale()); ?>" class="text-primary font-medium uppercase"><?php echo e(app()->getLocale()); ?></a>
        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($language !== app()->getLocale()): ?>
                <a href="/<?php echo e($language); ?>" class="text-gray-600 font-medium uppercase"><?php echo e($language); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/resources/views/components/header.blade.php ENDPATH**/ ?>