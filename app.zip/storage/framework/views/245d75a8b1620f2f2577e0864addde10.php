<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section id="<?php echo e($page->slug); ?>" class="section">
        <div class="py-48 px-8 max-sm:py-36">
            <div class="max-w-2xl max-lg:bg-white/70 max-lg:px-8 max-lg:py-12 max-lg:rounded-lg backdrop-blur-md">
                <?php echo $__env->make('blocks.blocks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/resources/views/blocks/page.blade.php ENDPATH**/ ?>