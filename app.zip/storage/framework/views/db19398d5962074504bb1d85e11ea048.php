<h1 class="text-gray-700 text-5xl font-semibold mb-16 mt-32 max-lg:mt-0 max-sm:text-4xl">
    <?php if(!empty($block['first_line'])): ?>
        <span class="block mb-2"><?php echo e($translator->translate($block,'first_line')); ?></span>
    <?php endif; ?>
    <?php if(!empty($block['second_line'])): ?>
        <span class="text-4xl max-sm:text-3xl"><?php echo e($translator->translate($block,'second_line')); ?></span>
    <?php endif; ?>
</h1>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/resources/views/blocks/hero.blade.php ENDPATH**/ ?>