<footer class="relative mt-16 px-4">
    <div class="flex flex-wrap items-center border-t p-4">
        <div class="w-1/3 max-md:w-full">
            <img class="h-12 w-auto max-md:mx-auto max-md:mb-4" src="/images/logo.svg" alt="">
        </div>
        <div class="w-1/3 max-md:w-full max-md:mb-4">
            <p class="text-gray-500 text-center">© Copyright Falcon International 2006</p>
        </div>
        <div class="w-1/3 max-md:w-full">
            <ul class="socials flex items-center w-auto justify-end max-md:justify-center">
                <?php $__currentLoopData = \App\Models\Social::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="ml-2">
                        <a href="<?php echo e($social->link); ?>" target="_blank">
                            <?php echo $social->icon; ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</footer>
<?php /**PATH /Users/Mmdv/Desktop/falconltd/resources/views/components/footer.blade.php ENDPATH**/ ?>