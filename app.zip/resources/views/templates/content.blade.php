@extends('layouts.web')

@section('content')
    @include('blocks.blocks')
@endsection
